Board name: MISTESP 2015
Contact: Jan Nyman, ControlThings Oy Ab 
jan.nyman@controlthings.fi
+358 50 3365052

The board is a 2-layer design. Board thickness 1.55 mm. No soldermask.
Requested quantity of boards: 10

The board has been created with Eagle, the .sch and .brd files are
included.

The Gerber files are generated using Eagle CAM job "gerb274x.cam":
    - component side *.cmp
    - solder side *.sol
    - silkscreen component side *.plc
    - solder stop component side *.stc
    - solder stop solder sid *.sts

The drill data is created with job named "excellon.cam".


